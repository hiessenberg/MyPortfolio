# Simple-Portfolio
Made a simple and a sample portfolio by using HTML, CSS and JavaScript
